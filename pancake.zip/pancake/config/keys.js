module.exports = {
    mongoURI: 'mongodb://0.0.0.0:27017/CakeDB',
    jwt: 'dev-jwt'

}


//mongodb://0.0.0.0:27017/pancakedb