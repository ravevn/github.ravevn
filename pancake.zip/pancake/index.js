const app = require ('./app')
const {connectToDb, getDb} = require('./db');

const port = process.env.PORT || 3000

let db;

connectToDb((err) =>{
   if (!err) {
      app.listen (port, function () {
      console.log (`Server has been started on ${port} port`)
      });
      db = getDb();

   } else {
      console.log(`MongoDB connection error: ${err}`)

   }
})

// создаем PORT 3000 и функцию с ответом от сервера

